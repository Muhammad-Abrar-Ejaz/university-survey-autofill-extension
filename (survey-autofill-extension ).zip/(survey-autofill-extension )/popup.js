// popup.js — Survey AutoFill with Apple Design interaction physics

let currentStrategy = 'position';
let groupCount = 0;

const statusDot    = document.getElementById('status-dot');
const statusText   = document.getElementById('status-text');
const groupsBadge  = document.getElementById('groups-badge');
const btnFill      = document.getElementById('btn-fill');
const btnFillText  = document.getElementById('btn-fill-text');
const posAccordion = document.getElementById('pos-accordion');
const posSlider    = document.getElementById('pos-slider');
const posDisplay   = document.getElementById('pos-display');
const toast        = document.getElementById('toast');
const strategyBtns = Array.from(document.querySelectorAll('.strategy-btn'));

// ── Helpers ────────────────────────────────────────────────────────────────

function setStatus(text, type = 'idle') {
  statusText.textContent = text;
  statusDot.className = 'status-dot';
  if (type === 'active') statusDot.classList.add('active');
  if (type === 'warn')   statusDot.classList.add('warn');
}

function showToast(msg, type = 'info', duration = 3200) {
  toast.className = `toast show ${type}`;
  toast.innerHTML = msg;
  clearTimeout(toast._timer);
  toast._timer = setTimeout(() => {
    toast.className = 'toast';
  }, duration);
}

function updateSliderFill() {
  const min = parseFloat(posSlider.min) || 1;
  const max = parseFloat(posSlider.max) || 10;
  const val = parseFloat(posSlider.value);
  const percent = ((val - min) / (max - min)) * 100;
  
  posSlider.style.background = `linear-gradient(to right, var(--accent) 0%, var(--accent) ${percent}%, var(--surface-element-hover) ${percent}%, var(--surface-element-hover) 100%)`;
  posDisplay.textContent = val;
}

async function sendToContent(action, extra = {}) {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab) return null;
  try {
    return await chrome.tabs.sendMessage(tab.id, { action, ...extra });
  } catch {
    // Content script not injected yet — inject it manually
    try {
      await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['content.js'] });
      return await chrome.tabs.sendMessage(tab.id, { action, ...extra });
    } catch {
      return null;
    }
  }
}

// ── Init: scan page ─────────────────────────────────────────────────────────

async function scanPage() {
  setStatus('Scanning survey page…', 'idle');
  groupsBadge.textContent = '—';
  btnFill.disabled = true;
  btnFillText.textContent = '⚡ Auto-Fill Questions';

  const res = await sendToContent('getGroups');

  if (!res) {
    setStatus('Cannot access tab or permissions', 'warn');
    showToast('⚠️ Cannot access tab. Refresh the survey page.', 'error', 4500);
    return;
  }

  groupCount = res.count || 0;
  groupsBadge.textContent = groupCount;

  if (groupCount === 0) {
    setStatus('No survey questions detected', 'warn');
    showToast('ℹ️ No radio questions detected. Ensure survey is open.', 'info', 4500);
    btnFill.disabled = true;
    btnFillText.textContent = '⚡ Auto-Fill Questions';
  } else {
    setStatus(`${groupCount} question${groupCount !== 1 ? 's' : ''} ready to fill`, 'active');
    btnFill.disabled = false;
    btnFillText.textContent = `⚡ Auto-Fill ${groupCount} Question${groupCount !== 1 ? 's' : ''}`;
    showToast(`✅ Found ${groupCount} question${groupCount !== 1 ? 's' : ''}. Ready!`, 'success', 2500);
  }
}

// ── Strategy Selection & Accessible Keyboard Navigation ───────────────────

function selectStrategy(strategyKey) {
  currentStrategy = strategyKey;

  strategyBtns.forEach(btn => {
    const isSelected = btn.dataset.strategy === strategyKey;
    btn.classList.toggle('active', isSelected);
    btn.setAttribute('aria-checked', isSelected ? 'true' : 'false');
    btn.setAttribute('tabindex', isSelected ? '0' : '-1');
    if (isSelected) btn.focus();
  });

  // Smooth spring accordion toggle for slider
  if (posAccordion) {
    if (currentStrategy === 'position') {
      posAccordion.classList.remove('collapsed');
    } else {
      posAccordion.classList.add('collapsed');
    }
  }
}

strategyBtns.forEach((btn, index) => {
  btn.addEventListener('click', () => {
    selectStrategy(btn.dataset.strategy);
  });

  // Radio arrow key navigation (Left/Up/Right/Down)
  btn.addEventListener('keydown', (e) => {
    let nextIndex = index;
    if (e.key === 'ArrowRight' || e.key === 'ArrowDown') {
      nextIndex = (index + 1) % strategyBtns.length;
      e.preventDefault();
    } else if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') {
      nextIndex = (index - 1 + strategyBtns.length) % strategyBtns.length;
      e.preventDefault();
    }
    if (nextIndex !== index) {
      selectStrategy(strategyBtns[nextIndex].dataset.strategy);
    }
  });
});

// ── Position Slider ────────────────────────────────────────────────────────

posSlider.addEventListener('input', updateSliderFill);

// ── Fill Button Interaction ────────────────────────────────────────────────

btnFill.addEventListener('click', async () => {
  btnFill.disabled = true;
  btnFill.classList.add('loading');
  btnFillText.textContent = 'Auto-filling survey…';

  const options = {
    strategy: currentStrategy === 'first' ? 'position' : currentStrategy,
    position: currentStrategy === 'first' ? 1 : parseInt(posSlider.value, 10),
  };

  const result = await sendToContent('autoFill', { options });

  btnFill.classList.remove('loading');
  btnFill.disabled = false;
  btnFillText.textContent = groupCount > 0 ? `⚡ Auto-Fill ${groupCount} Questions` : '⚡ Auto-Fill Questions';

  if (!result) {
    showToast('❌ Fill failed. Refresh page and try again.', 'error');
    return;
  }

  const { filled, skipped } = result;
  if (filled > 0) {
    showToast(`✅ Filled <strong>${filled}</strong> question${filled !== 1 ? 's' : ''}${skipped ? ` (${skipped} skipped)` : ''}`, 'success', 3500);
    setStatus(`Filled ${filled} of ${filled + skipped} questions`, 'active');
  } else {
    showToast('⚠️ Nothing was filled. All may already be answered.', 'info');
  }
});

// ── Highlight Unfilled ─────────────────────────────────────────────────────

document.getElementById('btn-highlight').addEventListener('click', async () => {
  const res = await sendToContent('highlightUnfilled');
  if (res && res.count === 0) {
    showToast('🎉 All questions are answered!', 'success');
  } else if (res) {
    showToast(`🔴 ${res.count} unanswered question${res.count !== 1 ? 's' : ''} highlighted`, 'info');
  }
});

// ── Clear Highlights ───────────────────────────────────────────────────────

document.getElementById('btn-clear').addEventListener('click', async () => {
  await sendToContent('clearHighlights');
  showToast('Outlines cleared.', 'info', 1800);
});

// ── Boot ───────────────────────────────────────────────────────────────────

updateSliderFill();
scanPage();

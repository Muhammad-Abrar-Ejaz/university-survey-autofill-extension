// content.js — Survey AutoFill content script

/**
 * Collects all radio button groups on the page and returns their metadata.
 * Returns an array of groups: { name, options: [{value, label, element}] }
 */
function getRadioGroups() {
  const groups = {};
  const allRadios = document.querySelectorAll('input[type="radio"]');

  allRadios.forEach((radio) => {
    const name = radio.name || `__unnamed_${radio.id || Math.random()}`;
    if (!groups[name]) {
      groups[name] = { name, options: [], element: null };
    }

    // Try to find a human-readable label
    let label = '';
    // 1. <label for="id">
    if (radio.id) {
      const labelEl = document.querySelector(`label[for="${CSS.escape(radio.id)}"]`);
      if (labelEl) label = labelEl.innerText.trim();
    }
    // 2. Wrapping <label>
    if (!label) {
      const parent = radio.closest('label');
      if (parent) label = parent.innerText.trim();
    }
    // 3. Sibling text node or span
    if (!label) {
      const sibling = radio.nextElementSibling;
      if (sibling) label = sibling.innerText.trim();
    }
    // 4. aria-label
    if (!label) label = radio.getAttribute('aria-label') || '';
    // 5. Fall back to value
    if (!label) label = radio.value;

    groups[name].options.push({
      value: radio.value,
      label: label.slice(0, 80),
    });
  });

  return Object.values(groups);
}

/**
 * Counts how many radio groups exist on the page.
 */
function countRadioGroups() {
  return getRadioGroups().length;
}

/**
 * Fill strategy:
 *   "position" – select the Nth option in every group (1-based, from left/top)
 *   "value"    – select the option whose value matches a given string
 *   "last"     – select the last option in every group
 *   "random"   – pick a random option in every group
 */
function autoFill({ strategy = 'position', position = 1, value = '' } = {}) {
  const allRadios = document.querySelectorAll('input[type="radio"]');
  const groups = {};

  // Group radios by name
  allRadios.forEach((radio) => {
    const name = radio.name || `__unnamed_${radio.id}`;
    if (!groups[name]) groups[name] = [];
    groups[name].push(radio);
  });

  let filled = 0;
  let skipped = 0;

  Object.entries(groups).forEach(([name, radios]) => {
    let target = null;

    if (strategy === 'position') {
      const idx = Math.min(position - 1, radios.length - 1);
      target = radios[Math.max(0, idx)];
    } else if (strategy === 'last') {
      target = radios[radios.length - 1];
    } else if (strategy === 'random') {
      target = radios[Math.floor(Math.random() * radios.length)];
    } else if (strategy === 'value') {
      target = radios.find((r) => r.value === value) || radios[0];
    }

    if (target && !target.disabled) {
      // Native click to trigger frameworks (React, Angular, etc.)
      target.click();
      // Also set directly
      target.checked = true;
      // Dispatch change + input events so form libraries detect it
      target.dispatchEvent(new Event('change', { bubbles: true }));
      target.dispatchEvent(new Event('input', { bubbles: true }));
      filled++;
    } else {
      skipped++;
    }
  });

  return { filled, skipped, total: Object.keys(groups).length };
}

/**
 * Highlight all unfilled radio groups with a red outline so the user can spot them.
 */
function highlightUnfilled() {
  const allRadios = document.querySelectorAll('input[type="radio"]');
  const groups = {};

  allRadios.forEach((radio) => {
    const name = radio.name || `__unnamed_${radio.id}`;
    if (!groups[name]) groups[name] = { radios: [], filled: false };
    if (radio.checked) groups[name].filled = true;
    groups[name].radios.push(radio);
  });

  let count = 0;
  Object.values(groups).forEach(({ radios, filled }) => {
    radios.forEach((r) => {
      const wrapper = r.closest('td, li, div, label, tr') || r.parentElement;
      if (wrapper) {
        if (!filled) {
          wrapper.style.outline = '2px solid #ff4444';
          wrapper.style.outlineOffset = '2px';
          count++;
        } else {
          wrapper.style.outline = '';
        }
      }
    });
  });

  return count;
}

/**
 * Clear all highlights.
 */
function clearHighlights() {
  document.querySelectorAll('input[type="radio"]').forEach((r) => {
    const wrapper = r.closest('td, li, div, label, tr') || r.parentElement;
    if (wrapper) wrapper.style.outline = '';
  });
}

// Listen for messages from the popup
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg.action === 'getGroups') {
    sendResponse({ groups: getRadioGroups(), count: countRadioGroups() });
  } else if (msg.action === 'autoFill') {
    const result = autoFill(msg.options || {});
    sendResponse(result);
  } else if (msg.action === 'highlightUnfilled') {
    const count = highlightUnfilled();
    sendResponse({ count });
  } else if (msg.action === 'clearHighlights') {
    clearHighlights();
    sendResponse({ ok: true });
  } else if (msg.action === 'ping') {
    sendResponse({ ok: true });
  }
  return true; // keep channel open for async
});

# 📋 Survey AutoFill – Chrome Extension

Automatically fill all radio-button questions on your university surveys in one click.

---

## ✅ Features

- **Auto-fills** all radio button groups on any survey/LMS page
- **4 strategies**: By Position, Highest Rating, Lowest Rating, or Random
- **Position picker** – choose exactly which option to pick (e.g. "always select option 4 out of 5")
- **Highlight unfilled** – red outline on any unanswered questions
- Works on **any university portal** (Blackboard, Moodle, Canvas, custom portals, etc.)
- **No data stored or sent** anywhere

---

## 🚀 Installation (Chrome)

1. Open Chrome and go to: `chrome://extensions/`
2. Turn on **Developer Mode** (toggle in the top-right corner)
3. Click **"Load unpacked"**
4. Select the `survey-autofill-extension` folder
5. The extension icon appears in your toolbar ✓

> 💡 **Tip:** Pin the extension by clicking the puzzle piece icon → pin 📌

---

## 🎯 How to Use

1. Navigate to your university survey page
2. Click the extension icon in your toolbar
3. It will **automatically scan** and show how many questions were found
4. Choose a **fill strategy**:
   - **By Position** – slide to choose the Nth option (e.g. 4 out of 5 = high rating)
   - **Highest** – always picks the last option (best score)
   - **Lowest** – always picks the first option
   - **Random** – random for each question
5. Click **⚡ AUTO-FILL ALL QUESTIONS**
6. Done! Review and submit your survey normally.

---

## 📖 Tips

- After filling, click **"Highlight unfilled"** to spot any missed questions
- Some survey pages load questions dynamically – scroll down to load all questions first, then autofill
- If the extension says "Cannot access this page", try refreshing the survey page

---

## 🔒 Privacy

- No data is collected or sent anywhere
- Works entirely in your browser
- No account required
